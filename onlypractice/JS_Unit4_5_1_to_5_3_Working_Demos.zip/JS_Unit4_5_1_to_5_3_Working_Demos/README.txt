JAVASCRIPT WORKING DEMOS
Coverage: Unit 4 complete + Unit 5.1 to 5.3

HOW TO RUN
1. Extract the ZIP file.
2. Open index.html in Chrome, Edge, Firefox, or another modern browser.
3. Click any demo from the menu.
4. Open DevTools (F12) to inspect the DOM and JavaScript.

DEMO MAPPING
UNIT 4
01 - DOM Introduction and Document Object
02 - Access elements and styles
03 - Create / modify / remove DOM elements
04 - Event handlers and addEventListener()
05 - Integrated DOM form interaction

UNIT 5.1
06 - Object references, copying and garbage collection

UNIT 5.2
07 - Object methods, this, constructor function and new

UNIT 5.3
08 - Object-to-primitive conversion and primitive methods

Teaching use: run the demo, ask students to predict output, inspect DOM in DevTools, then modify one requirement.
